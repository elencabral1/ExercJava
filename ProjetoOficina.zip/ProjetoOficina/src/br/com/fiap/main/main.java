package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Carro;
import br.com.fiap.beans.Colaborador;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.ParteCarro;
import br.com.fiap.beans.TesteOficina;

public class main {

	public static void main(String[] args) {
	
		
		TesteOficina objTesteOficina = new TesteOficina(JOptionPane.showInputDialog("Digite o nome da Oficina"),
				JOptionPane.showInputDialog("Digite o CNPJ"));
		
		Endereco objEndereco = new Endereco(JOptionPane.showInputDialog("Digite o logradouro"),
				Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
		
		Carro objCarro = new Carro();
		
		ParteCarro objParteCarro = new ParteCarro();
		
		Colaborador objColaborador = new Colaborador();
		
		
		objTesteOficina.setCarro(objCarro);
		objTesteOficina.setEndereco(objEndereco);
		objTesteOficina.setColaborador(objColaborador);
		
		objCarro.setParteCarro(objParteCarro);
		
		
		
	}

}
